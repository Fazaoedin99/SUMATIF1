package com.example.sumatif1genapmisbahudin_faza

class DataBuku (gambar: Int,buku: String)
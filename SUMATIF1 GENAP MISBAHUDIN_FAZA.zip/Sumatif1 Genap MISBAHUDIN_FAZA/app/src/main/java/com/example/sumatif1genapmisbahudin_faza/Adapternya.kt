package com.example.sumatif1genapmisbahudin_faza

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Adapternya : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adapternya)
    }
}
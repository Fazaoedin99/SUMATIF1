package com.example.sumatif1genapmisbahudin_faza

class DataGambar (val gambar:Int,val Buku:String)

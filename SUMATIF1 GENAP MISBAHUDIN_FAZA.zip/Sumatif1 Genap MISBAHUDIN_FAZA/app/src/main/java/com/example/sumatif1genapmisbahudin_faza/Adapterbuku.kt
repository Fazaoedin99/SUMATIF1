package com.example.sumatif1genapmisbahudin_faza

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Adapterbuku(data: ArrayList<DataGambar>) : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adapterbuku)
    }
    fun Keguru(view: View) {
        val pindah2 = Intent(this, AdapterGuru::class.java)
        startActivity(pindah2)
    }
}